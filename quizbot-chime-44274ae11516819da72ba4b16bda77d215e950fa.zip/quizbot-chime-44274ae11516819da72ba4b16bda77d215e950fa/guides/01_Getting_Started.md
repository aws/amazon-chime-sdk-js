### Getting Started

For guidance and examples on how to use the Amazon Chime SDK for JavaScript in your application, see [API overview](https://aws.github.io/amazon-chime-sdk-js/modules/apioverview.html) for more information.