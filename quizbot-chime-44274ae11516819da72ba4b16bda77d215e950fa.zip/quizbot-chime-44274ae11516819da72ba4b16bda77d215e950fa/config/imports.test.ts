import * as Foo from 'amazon-chime-sdk-js';

console.log('Imported:', Foo);

