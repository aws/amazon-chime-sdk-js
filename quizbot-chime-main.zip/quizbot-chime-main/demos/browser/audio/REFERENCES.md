File | Source
---- | ------
speech.mp3 | Excerpt from speech by Barack Obama<br/>November 20, 2014<br/>Source: The White House</br>President Obama delivers an address to the nation on immigration.<br/>https://millercenter.org/the-presidency/presidential-speeches/november-20-2014-address-nation-immigration
speech_stereo.mp3 | Audio test file for stereo verification


